export const categories = [
  "All",
  "Project",
  "Design",
  "Photography",
  "Development",
]

export interface Gallery {
  imgUrl? : string,
  title: string, 
  subtitle:string
}

// export const galleries : Gallery[] =[{
  
// }]