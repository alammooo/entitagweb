export const links: string[] = [
  "Services",
  "Process",
  // "Testimonial",
  "Portofolio",
  "Pricing",
  "Contact",
]
