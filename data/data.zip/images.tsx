export const image = [
  "https://raw.githubusercontent.com/reduxjs/redux/master/logo/logo.png",
  "https://seeklogo.com/images/N/next-js-logo-8FCFF51DD2-seeklogo.com.png",
  "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d5/Tailwind_CSS_Logo.svg/600px-Tailwind_CSS_Logo.svg.png?20211001194333",
  "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d9/Node.js_logo.svg/590px-Node.js_logo.svg.png?20170401104355",
  "https://wiki.postgresql.org/images/thumb/a/a4/PostgreSQL_logo.3colors.svg/540px-PostgreSQL_logo.3colors.svg.png",
  "https://upload.wikimedia.org/wikipedia/commons/thumb/6/6a/JavaScript-logo.png/600px-JavaScript-logo.png?20120221235433",
  "https://seeklogo.com/images/P/pinia-logo-51BF712FB0-seeklogo.com.png",
  "https://seeklogo.com/images/V/vuejs-logo-17D586B587-seeklogo.com.png",
]
