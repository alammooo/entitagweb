export const services = [
  {
    icon: <div></div>,
    title: "Web design",
    text: "Those who do not know how to pursue pleasure rationally encounter consequences that are extremely painful.",
  },
  {
    icon: <div></div>,
    title: "Development",
    text: "Due to its widespread use as filler text for layouts, non-readability is of great importance.",
  },
  {
    icon: <div></div>,
    title: "Branding",
    text: "There are many variations of passages of available, but the majority alteration in some form.",
  },
  {
    icon: <div></div>,
    title: "Easy to costumize",
    text: "The generated Lorem Ipsum is therefore always free from repetition, injected humour.",
  },
  {
    icon: <div></div>,
    title: "Unrivaled Quality",
    text: "The generated Lorem Ipsum is therefore always free from repetition, injected humour.",
  },
  {
    icon: <div></div>,
    title: "Online Marketing",
    text: "This is required when, for example, the is not yet available. Dummy text is also known as 'fill text'. ",
  },
]
